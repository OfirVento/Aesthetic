import React, { useState } from 'react';
import { AppStep, CapturedImages, SimulationState } from './types';
import Welcome from './components/Welcome';
import Capture from './components/Capture';
import Simulation from './components/Simulation';
import Export from './components/Export';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep>(AppStep.WELCOME);
  const [images, setImages] = useState<CapturedImages>({});
  const [simState, setSimState] = useState<SimulationState>({
    skinTexture: 0,
    upperFaceToxin: 0,
    lipEnhancement: 0,
    noseRefinement: 0,
    jawlineDefinition: 0,
    preset: 'NATURAL'
  });

  const handleStart = () => setStep(AppStep.CAPTURE);
  const handleCaptureComplete = (captured: CapturedImages) => {
    setImages(captured);
    setStep(AppStep.SIMULATION);
  };
  const handleFinish = (finalSimImage?: string) => {
    if (finalSimImage) setImages(prev => ({ ...prev, simulatedFront: finalSimImage }));
    setStep(AppStep.EXPORT);
  };
  const reset = () => {
    setStep(AppStep.WELCOME);
    setImages({});
    setSimState({ 
      skinTexture: 0, 
      upperFaceToxin: 0, 
      lipEnhancement: 0, 
      noseRefinement: 0, 
      jawlineDefinition: 0, 
      preset: 'NATURAL' 
    });
  };

  return (
    <div className="h-screen bg-stone-50 text-slate-900 flex flex-col overflow-hidden">
      <header className="px-6 py-4 flex justify-between items-center bg-white border-b border-stone-100 z-50 shrink-0">
        <div className="flex items-center gap-3 cursor-pointer" onClick={reset}>
          <div className="w-7 h-7 rounded-lg bg-stone-900 flex items-center justify-center text-white text-[10px] font-bold">A</div>
          <span className="font-serif text-lg tracking-tight text-stone-800">Aesthetic Styling</span>
        </div>
        <nav className="hidden md:flex gap-6 text-[9px] font-black uppercase tracking-[0.2em] text-stone-300">
          <span className={step === AppStep.CAPTURE ? 'text-stone-900 font-black' : ''}>01 Scan</span>
          <span className={step === AppStep.SIMULATION ? 'text-stone-900 font-black' : ''}>02 Simulation</span>
          <span className={step === AppStep.EXPORT ? 'text-stone-900 font-black' : ''}>03 Outcome</span>
        </nav>
      </header>
      <main className="flex-1 overflow-hidden relative">
        {step === AppStep.WELCOME && <Welcome onStart={handleStart} onUpload={(d) => handleCaptureComplete({ front: d })} />}
        {step === AppStep.CAPTURE && <Capture onComplete={handleCaptureComplete} />}
        {step === AppStep.SIMULATION && <Simulation images={images} simState={simState} onStateChange={setSimState} onNext={handleFinish} />}
        {step === AppStep.EXPORT && <Export images={images} simState={simState} onReset={reset} />}
      </main>
    </div>
  );
};

export default App;