import React, { useState } from 'react';
import { CapturedImages, SimulationState } from '../types';
import { GoogleGenAI } from "@google/genai";

interface SimulationProps {
  images: CapturedImages;
  simState: SimulationState;
  onStateChange: (state: SimulationState) => void;
  onNext: (finalImage?: string) => void;
}

const Simulation: React.FC<SimulationProps> = ({ images, simState, onStateChange, onNext }) => {
  const [isRendering, setIsRendering] = useState(false);
  const [activeImage, setActiveImage] = useState<string | null>(null);
  const [history, setHistory] = useState<string[]>([]);

  const isAllZero = 
    simState.skinTexture === 0 && 
    simState.upperFaceToxin === 0 && 
    simState.lipEnhancement === 0 && 
    simState.noseRefinement === 0 && 
    simState.jawlineDefinition === 0;

  const buildPrompt = (state: SimulationState) => {
    const getSkinPrompt = (v: number) => {
      if (v === 0) return "STRICT PIXEL PRESERVATION: Do not modify skin texture.";
      if (v < 30) return "MICRO-REFRESH: Subtle softening of fine textures.";
      if (v < 60) return "CLINICAL SMOOTHING: Moderate reduction of irregularities.";
      return "DRAMATIC REFINEMENT: Significant resurfacing and texture homogenization.";
    };

    const getToxinPrompt = (v: number) => {
      if (v === 0) return "STRICT PIXEL PRESERVATION: Do not modify forehead/brows.";
      if (v < 30) return "SOFT RELAXATION: Very subtle softening of dynamic lines.";
      if (v < 60) return "MODERATE TOXIN: Noticeable reduction in forehead and glabella lines.";
      return "TOTAL TOXIN LIFT: Maximum relaxation of forehead muscles and subtle brow lift.";
    };

    const getLipPrompt = (v: number) => {
      if (v === 0) return "STRICT PIXEL PRESERVATION: Do not modify lips.";
      if (v < 30) return "HYDRATION EFFECT: Extremely subtle plumping and gloss-like finish.";
      if (v < 50) return "NATURAL VOLUME: Soft enhancement of the vermilion border and cupids bow.";
      if (v < 70) return "HA DEFINITION: Balanced volume increase with clear structural definition.";
      return "BOLD AUGMENTATION: Significant volume increase. The lip surface must be perfectly smooth, seamless, and airbrushed with no lumps or harsh edges.";
    };

    const getNosePrompt = (v: number) => {
      if (v === 0) return "STRICT PIXEL PRESERVATION: Do not modify nose.";
      if (v < 40) return "MICRO-ADJUSTMENT: Very slight straightening of the bridge.";
      if (v < 70) return "LIQUID RHINOPLASTY: Noticeable smoothing of dorsal hump and tip refinement.";
      return "STRUCTURAL RESHAPING: Precise narrowing of the bridge and elevation of the nasal tip.";
    };

    const getJawPrompt = (v: number) => {
      if (v === 0) return "STRICT PIXEL PRESERVATION: Do not modify jawline/chin.";
      if (v < 40) return "SUBTLE TIGHTENING: Light sharpening of the mandibular line.";
      if (v < 70) return "CONTOUR DEFINITION: Noticeable enhancement of the jaw angle and chin projection.";
      return "DRAMATIC SCULPTING: Sharp, chiseled jawline with high-definition modeling.";
    };

    return `SYSTEM INSTRUCTION: You are an expert medical aesthetic visualization engine.
    OBJECTIVE: Apply high-fidelity modifications to the provided face based on these clinical parameters:
    1. SKIN (${state.skinTexture}%): ${getSkinPrompt(state.skinTexture)}
    2. TOXIN (${state.upperFaceToxin}%): ${getToxinPrompt(state.upperFaceToxin)}
    3. LIPS (${state.lipEnhancement}%): ${getLipPrompt(state.lipEnhancement)}
    4. NOSE (${state.noseRefinement}%): ${getNosePrompt(state.noseRefinement)}
    5. JAWLINE (${state.jawlineDefinition}%): ${getJawPrompt(state.jawlineDefinition)}
    
    CRITICAL CONSTRAINTS:
    - Maintain 100% identity of eyes, hair, clothing, and background.
    - If any value is 0%, that region MUST remain untouched (pixel-perfect preservation).
    - Ensure lighting and shadows are anatomically consistent with the modifications.
    - For high intensity lip changes, ensure the result is elegant and smooth, avoiding unnatural artifacts.`;
  };

  const handleRender = async () => {
    if (isAllZero) {
      setActiveImage(null);
      return;
    }

    setIsRendering(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const base64Data = images.front?.split(',')[1];
      if (!base64Data) return;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: {
          parts: [
            { inlineData: { data: base64Data, mimeType: 'image/jpeg' } },
            { text: buildPrompt(simState) },
          ],
        },
      });

      const part = response.candidates?.[0]?.content?.parts.find(p => p.inlineData);
      if (part?.inlineData) {
        const newImage = `data:image/png;base64,${part.inlineData.data}`;
        setActiveImage(newImage);
        setHistory(prev => [...prev, newImage].slice(-10));
      }
    } catch (error) {
      console.error("Simulation error:", error);
    } finally {
      setIsRendering(false);
    }
  };

  const handleSliderChange = (key: keyof SimulationState, val: number) => {
    onStateChange({ ...simState, [key]: val, preset: 'CUSTOM' });
  };

  const Slider = ({ label, value, field }: { label: string, value: number, field: keyof SimulationState }) => (
    <div className="space-y-3">
      <div className="flex justify-between items-center text-[11px] font-black uppercase tracking-[0.15em]">
        <span className="text-stone-500">{label}</span>
        <span className={value > 0 ? 'text-stone-900' : 'text-stone-300'}>{value}%</span>
      </div>
      <div className="relative h-4 flex items-center">
        <input 
          type="range" 
          min="0" 
          max="100" 
          step="5"
          value={value}
          onChange={(e) => handleSliderChange(field, parseInt(e.target.value))}
          className="w-full h-1 bg-stone-200/50 appearance-none rounded-full accent-stone-900 cursor-pointer z-10"
        />
        <div className="absolute inset-0 flex items-center pointer-events-none">
           <div className="h-1 bg-stone-900 rounded-full" style={{ width: `${value}%` }}></div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-full flex flex-col overflow-hidden bg-stone-100">
      <div className="flex-1 flex overflow-hidden min-h-0">
        <div className="w-72 bg-stone-50 border-r border-stone-200 flex flex-col z-20 shrink-0 shadow-[2px_0_10px_rgba(0,0,0,0.02)]">
          <div className="p-6 pb-2">
            <h2 className="font-serif text-xl text-stone-800 uppercase tracking-tighter">Styling Panel</h2>
          </div>
          <div className="flex-1 px-6 py-4 space-y-8 overflow-y-auto no-scrollbar">
            <Slider label="Skin Texture" value={simState.skinTexture} field="skinTexture" />
            <Slider label="Upper Face (Toxin)" value={simState.upperFaceToxin} field="upperFaceToxin" />
            <Slider label="Lip Architecture" value={simState.lipEnhancement} field="lipEnhancement" />
            <Slider label="Nasal Profile" value={simState.noseRefinement} field="noseRefinement" />
            <Slider label="Jawline Definition" value={simState.jawlineDefinition} field="jawlineDefinition" />
          </div>
        </div>

        <div className="flex-1 p-6 flex gap-6 min-h-0 items-stretch justify-center">
          <div className="flex-1 flex flex-col min-h-0">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3 text-center">Baseline</span>
            <div className="flex-1 rounded-[32px] overflow-hidden bg-white shadow-xl border border-stone-200 relative min-h-0 group">
               <img src={images.front} className="w-full h-full object-contain group-hover:scale-[1.02] transition-transform duration-1000" alt="Baseline" />
               <div className="absolute top-5 left-5 px-4 py-2 bg-white/90 backdrop-blur-md rounded-full border border-stone-100 text-[10px] font-black tracking-widest uppercase text-stone-800 shadow-sm">Original</div>
            </div>
          </div>
          
          <div className="flex-1 flex flex-col min-h-0">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-3 text-center">Design</span>
            <div className="flex-1 rounded-[32px] overflow-hidden bg-white shadow-xl border border-stone-200 relative min-h-0 group">
              {isRendering && (
                <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/40 backdrop-blur-md">
                  <div className="flex flex-col items-center gap-3">
                    <div className="w-10 h-10 border-2 border-stone-900 border-t-transparent rounded-full animate-spin"></div>
                    <span className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-900/60">Simulating...</span>
                  </div>
                </div>
              )}
              <img src={activeImage || images.front} className={`w-full h-full object-contain group-hover:scale-[1.02] transition-all duration-1000 ${isRendering ? 'opacity-30 blur-sm' : 'opacity-100'}`} alt="Simulation" />
              <div className="absolute top-5 right-5 px-4 py-2 bg-stone-900/90 backdrop-blur-md rounded-full text-[10px] font-black tracking-widest uppercase text-white/95 border border-white/10 shadow-lg">Active Design</div>
            </div>
          </div>
        </div>
      </div>

      <div className="h-32 bg-white border-t border-stone-200 flex z-30 shrink-0 shadow-[0_-4px_20px_rgba(0,0,0,0.03)]">
        <div className="w-72 border-r border-stone-100 px-6 flex flex-col justify-center gap-2 bg-stone-50/30">
          <button 
            onClick={handleRender}
            disabled={isRendering}
            className={`w-full py-4 rounded-full font-black text-[10px] uppercase tracking-[0.25em] shadow-lg transition-all active:scale-[0.98] ${isRendering ? 'bg-stone-200 text-stone-400 cursor-not-allowed' : 'bg-stone-900 text-white hover:bg-black hover:shadow-stone-900/20'}`}
          >
            {isRendering ? 'Processing...' : 'Apply Simulation'}
          </button>
          <button 
            onClick={() => onNext(activeImage || undefined)}
            className="w-full text-stone-400 py-1 font-black text-[9px] uppercase tracking-widest hover:text-stone-900 transition-colors"
          >
            Finalize Styling
          </button>
        </div>

        <div className="flex-1 px-10 flex items-center gap-10 overflow-hidden">
           <div className="flex-shrink-0 flex flex-col items-start pr-8 border-r border-stone-100">
             <span className="text-[10px] font-black uppercase tracking-[0.3em] text-stone-400 mb-1.5">History</span>
             <div className="w-12 h-1 bg-stone-900 rounded-full"></div>
           </div>
           <div className="flex gap-4 overflow-x-auto no-scrollbar items-center py-4 h-full">
             <button onClick={() => setActiveImage(null)} className={`w-16 h-16 rounded-2xl overflow-hidden border-2 transition-all duration-500 flex-shrink-0 relative ${!activeImage ? 'border-stone-900 scale-110 shadow-xl z-10' : 'border-transparent opacity-40 hover:opacity-100'}`}><img src={images.front} className="w-full h-full object-cover" /></button>
             {history.map((img, idx) => (
               <button key={idx} onClick={() => setActiveImage(img)} className={`w-16 h-16 rounded-2xl overflow-hidden border-2 transition-all duration-500 flex-shrink-0 relative ${activeImage === img ? 'border-stone-900 scale-110 shadow-xl z-10' : 'border-transparent opacity-40 hover:opacity-100'}`}><img src={img} className="w-full h-full object-cover" /></button>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default Simulation;