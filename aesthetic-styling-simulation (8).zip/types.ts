export enum AppStep {
  WELCOME = 'WELCOME',
  CAPTURE = 'CAPTURE',
  SIMULATION = 'SIMULATION',
  EXPORT = 'EXPORT'
}

export interface SimulationState {
  skinTexture: number; 
  upperFaceToxin: number; 
  lipEnhancement: number; 
  noseRefinement: number; 
  jawlineDefinition: number; 
  preset: 'NATURAL' | 'BALANCED' | 'ENHANCED' | 'CUSTOM';
}

export interface CapturedImages {
  front?: string;
  simulatedFront?: string;
}