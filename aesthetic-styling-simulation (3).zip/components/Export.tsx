import React, { useState } from 'react';
import { CapturedImages, SimulationState } from '../types';

interface ExportProps {
  images: CapturedImages;
  simState: SimulationState;
  onReset: () => void;
}

const Export: React.FC<ExportProps> = ({ images, simState, onReset }) => {
  const [activeTab, setActiveTab] = useState<'RECIPE' | 'VISUAL'>('VISUAL');

  const getRecipe = () => {
    const items = [];
    if (simState.upperFaceToxin > 0) {
      const units = Math.round(simState.upperFaceToxin * 0.4) + 12;
      items.push({ 
        label: 'Botulinum Toxin Type A', 
        detail: `${units} Units`, 
        material: 'OnabotulinumtoxinA',
        sites: 'Frontalis / Glabella Complex' 
      });
    }
    if (simState.lipEnhancement > 0) {
      const volume = (0.5 + (simState.lipEnhancement / 200)).toFixed(1);
      items.push({ 
        label: 'Lip Volumizer', 
        detail: `${volume} ml`, 
        material: 'HA Soft Cohesive Filler',
        sites: 'Vermilion Border & Body' 
      });
    }
    if (simState.noseRefinement > 0) {
      items.push({ 
        label: 'Nasal Structural Filler', 
        detail: '0.4 ml', 
        material: 'High G-Prime HA',
        sites: 'Bridge Straightening / Tip Lift' 
      });
    }
    if (simState.jawlineDefinition > 0) {
      const volume = (simState.jawlineDefinition > 50 ? '2.0' : '1.0');
      items.push({ 
        label: 'Mandibular Contour Filler', 
        detail: `${volume} ml`, 
        material: 'Cohesive Structural HA',
        sites: 'Mandibular Angle / Chin' 
      });
    }
    if (simState.skinTexture > 0) {
      items.push({ 
        label: 'Dermal Bio-stimulant', 
        detail: '2.0 ml', 
        material: 'Non-crosslinked Hyaluronic Acid',
        sites: 'Full Face Micro-droplet' 
      });
    }
    return items;
  };

  const recipe = getRecipe();

  return (
    <div className="h-full flex flex-col bg-stone-50 overflow-hidden fade-in">
      <div className="bg-white border-b border-stone-200 px-8 pt-8 shrink-0">
        <div className="max-w-4xl mx-auto">
          <div className="mb-6 flex justify-between items-end">
            <div>
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-stone-400 block mb-1">Step 03 — Final Outcome</span>
              <h1 className="font-serif text-3xl text-stone-800 italic">Clinical Treatment Plan</h1>
            </div>
            <div className="text-right hidden md:block">
              <p className="text-[9px] font-black uppercase tracking-widest text-stone-300">Protocol ID</p>
              <p className="text-xs font-mono text-stone-500">#AES-{Math.floor(Math.random()*9000)+1000}</p>
            </div>
          </div>
          <div className="flex gap-8">
            <button 
              onClick={() => setActiveTab('VISUAL')} 
              className={`pb-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all border-b-2 ${activeTab === 'VISUAL' ? 'border-stone-900 text-stone-900' : 'border-transparent text-stone-300 hover:text-stone-400'}`}
            >
              Visual Mapping
            </button>
            <button 
              onClick={() => setActiveTab('RECIPE')} 
              className={`pb-4 text-[10px] font-black uppercase tracking-[0.2em] transition-all border-b-2 ${activeTab === 'RECIPE' ? 'border-stone-900 text-stone-900' : 'border-transparent text-stone-300 hover:text-stone-400'}`}
            >
              Clinical Recipe
            </button>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar p-8">
        <div className="max-w-4xl mx-auto h-full">
          {activeTab === 'VISUAL' ? (
            <div className="h-full flex flex-col items-center">
              <div className="relative w-full max-w-2xl aspect-[3/4] bg-white rounded-[40px] shadow-2xl border-[12px] border-white overflow-hidden">
                <img src={images.simulatedFront || images.front} className="w-full h-full object-cover" alt="Final" />
                
                <div className="absolute inset-0 pointer-events-none">
                  {simState.upperFaceToxin > 0 && (
                    <div className="absolute top-[18%] left-[50%] -translate-x-1/2 flex flex-col items-center pointer-events-auto">
                      <div className="w-4 h-4 rounded-full border-2 border-white bg-blue-500 shadow-lg animate-pulse"></div>
                      <div className="mt-2 bg-white/95 backdrop-blur px-3 py-1 rounded-lg shadow-xl border border-stone-100">
                        <span className="text-[9px] font-black text-stone-900 uppercase">Toxin Site</span>
                      </div>
                    </div>
                  )}

                  {simState.noseRefinement > 0 && (
                    <div className="absolute top-[42%] left-[50%] -translate-x-1/2 flex flex-col items-center pointer-events-auto">
                      <div className="w-4 h-4 rounded-full border-2 border-white bg-amber-500 shadow-lg"></div>
                      <div className="mt-2 bg-white/95 backdrop-blur px-3 py-1 rounded-lg shadow-xl border border-stone-100">
                        <span className="text-[9px] font-black text-stone-900 uppercase">Nasal Bridge</span>
                      </div>
                    </div>
                  )}

                  {simState.lipEnhancement > 0 && (
                    <div className="absolute top-[64%] left-[50%] -translate-x-1/2 flex flex-col items-center pointer-events-auto">
                      <div className="w-4 h-4 rounded-full border-2 border-white bg-pink-500 shadow-lg animate-pulse"></div>
                      <div className="mt-2 bg-white/95 backdrop-blur px-3 py-1 rounded-lg shadow-xl border border-stone-100">
                        <span className="text-[9px] font-black text-stone-900 uppercase">HA Volumization</span>
                      </div>
                    </div>
                  )}

                  {simState.jawlineDefinition > 0 && (
                    <div className="absolute bottom-[22%] right-[28%] flex flex-col items-end pointer-events-auto">
                      <div className="w-4 h-4 rounded-full border-2 border-white bg-stone-700 shadow-lg"></div>
                      <div className="mt-2 bg-white/95 backdrop-blur px-3 py-1 rounded-lg shadow-xl border border-stone-100">
                        <span className="text-[9px] font-black text-stone-900 uppercase">Structural Support</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
              <p className="mt-6 text-[10px] font-black uppercase tracking-[0.3em] text-stone-300">Target Area Visualization</p>
            </div>
          ) : (
            <div className="bg-white rounded-[32px] border border-stone-200 p-10 shadow-sm space-y-8">
              <div className="flex justify-between items-center border-b border-stone-100 pb-6">
                <h3 className="font-serif text-2xl text-stone-800">Prescription Protocol</h3>
                <p className="text-[10px] font-black uppercase tracking-widest text-stone-400">Issued: {new Date().toLocaleDateString()}</p>
              </div>
              
              <div className="space-y-8">
                {recipe.length > 0 ? (
                  recipe.map((item, idx) => (
                    <div key={idx} className="flex gap-6 items-start group">
                      <div className="w-10 h-10 rounded-xl bg-stone-50 border border-stone-100 flex items-center justify-center text-stone-300 group-hover:bg-stone-900 group-hover:text-white transition-all duration-300 shrink-0">
                        <i className={`fa-solid ${item.label.includes('Toxin') ? 'fa-syringe' : 'fa-droplet'} text-[10px]`}></i>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between items-center mb-1">
                          <h4 className="text-[11px] font-black uppercase tracking-widest text-stone-900">{item.label}</h4>
                          <span className="text-[11px] font-bold bg-stone-50 px-3 py-1 rounded-full border border-stone-100">{item.detail}</span>
                        </div>
                        <p className="text-[9px] text-stone-400 uppercase tracking-widest mb-2 italic">{item.material}</p>
                        <div className="bg-stone-50/50 p-3 rounded-lg border border-stone-100/50">
                          <p className="text-[10px] text-stone-600"><span className="font-bold mr-2 text-stone-400">SITES:</span> {item.sites}</p>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="py-20 text-center">
                    <p className="text-sm italic text-stone-300">No treatments selected. Please return to simulation.</p>
                  </div>
                )}
              </div>

              <div className="mt-12 pt-8 border-t border-stone-100">
                <div className="bg-stone-900 rounded-2xl p-6 text-white">
                  <h4 className="text-[9px] font-black uppercase tracking-[0.4em] mb-3 opacity-50">Clinical Notes</h4>
                  <p className="text-[11px] leading-relaxed font-medium">
                    Maintain anatomical symmetry as primary focus. Aspirate prior to all bolus injections. 
                    Recommended follow-up in 14 days for toxin assessment.
                  </p>
                </div>
              </div>
            </div>
          )}

          <div className="flex justify-center gap-4 mt-12 pb-12">
            <button onClick={() => window.print()} className="px-8 py-4 bg-white border border-stone-200 rounded-full text-[10px] font-black uppercase tracking-[0.2em] text-stone-900 hover:bg-stone-50 transition-all flex items-center gap-2">
              <i className="fa-solid fa-print"></i> Print Protocol
            </button>
            <button onClick={onReset} className="px-10 py-4 bg-stone-900 text-white rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-xl hover:bg-black transition-all">
              New Consultation
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Export;